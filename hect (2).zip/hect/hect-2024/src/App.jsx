import React from 'react';
import './App.css'; // Ensure your CSS file is properly linked
import 'bootstrap/dist/css/bootstrap.min.css';
import ImageCarousel from './ImageCarousel.js'; // New Carousel


// TopBar Component
const TopBar = () => (
  <div className="top-bar">
    <div className="container">
      <div className="contact-info">
        <i className="fa fa-envelope"></i> info@example.com &nbsp; | &nbsp;
        <i className="fa fa-phone"></i> +123 456 7890
      </div>
      <div className="social-icons">
        <a href="#" className="fa fa-facebook"></a>
        <a href="#" className="fa fa-twitter"></a>
        <a href="#" className="fa fa-instagram"></a>
      </div>
    </div>
  </div>
);

// Navbar Component
const Navbar = () => (
  <nav className="navbar">
    <div className="container">
      <a className="logo" href="#">MySite</a>
      <ul className="nav-links">
        <li><a href="#">Home</a></li>
        <li className="dropdown">
          <a href="#">Categories</a>
          <ul className="dropdown-menu">
            <li><a href="#">Category 1</a></li>
            <li><a href="#">Category 2</a></li>
          </ul>
        </li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <div className="navbar-buttons">
        <button className="btn-primary">Sign Up</button>
        <button className="btn-secondary">Login</button>
      </div>
    </div>
  </nav>
);

// Carousel Component
const Carousel = () => (
  <div className="carousel">
    <div className="carousel-item">
      <h1>First Slide</h1>
      <p>Some descriptive text here.</p>
    </div>
    <div className="carousel-item">
      <h1>Second Slide</h1>
      <p>Some more descriptive text here.</p>
    </div>
    <div className="carousel-item">
      <h1>Third Slide</h1>
      <p>Even more descriptive text here.</p>
    </div>
    <div className="carousel-buttons">
      <button className="prev">Prev</button>
      <button className="next">Next</button>
    </div>
  </div>
);

// Main App Component
const App = () => {
  return (
    <div className="app">
      <TopBar />
      <Navbar />
      <Carousel />
    </div>
  );
};

export default App;
