import { Carousel } from 'react-bootstrap';

const ImageCarousel = () => (
  <Carousel>
    <Carousel.Item>
      <img
        className="d-block w-100"
        src="https://via.placeholder.com/800x400?text=First+Slide"
        alt="First slide"
      />
      <Carousel.Caption>
        <h3>First Slide</h3>
        <p>Some descriptive text here.</p>
      </Carousel.Caption>
    </Carousel.Item>
    <Carousel.Item>
      <img
        className="d-block w-100"
        src="https://via.placeholder.com/800x400?text=Second+Slide"
        alt="Second slide"
      />
      <Carousel.Caption>
        <h3>Second Slide</h3>
        <p>Some more descriptive text here.</p>
      </Carousel.Caption>
    </Carousel.Item>
    <Carousel.Item>
      <img
        className="d-block w-100"
        src="https://via.placeholder.com/800x400?text=Third+Slide"
        alt="Third slide"
      />
      <Carousel.Caption>
        <h3>Third Slide</h3>
        <p>Even more descriptive text here.</p>
      </Carousel.Caption>
    </Carousel.Item>
  </Carousel>
);

export default ImageCarousel;
